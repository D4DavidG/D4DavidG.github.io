<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id           = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$name         = $_POST['name'] ?? '';
$instructorId = isset($_POST['instructor_id']) ? (int)$_POST['instructor_id'] : 0;
$description  = $_POST['description'] ?? '';
$classTimeRaw = $_POST['class_time'] ?? '';
$capacity     = isset($_POST['capacity']) ? (int)$_POST['capacity'] : 0;

// 'YYYY-MM-DDTHH:MM' -> 'YYYY-MM-DD HH:MM:SS'
$classTime = str_replace('T', ' ', $classTimeRaw) . ':00';

$name        = $conn->real_escape_string($name);
$description = $conn->real_escape_string($description);
$classTime   = $conn->real_escape_string($classTime);

$query = "UPDATE classes
          SET instructor_id = $instructorId,
              name          = '$name',
              description   = '$description',
              class_time    = '$classTime',
              capacity      = $capacity
          WHERE id = $id";

$conn->query($query);

header("Location: manageClasses.php");
exit;
