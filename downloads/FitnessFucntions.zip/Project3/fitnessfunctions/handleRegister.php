<?php
session_start();
require_once "db.php";

$fullName = $_POST['full_name'] ?? '';
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Basic validation
$fullName = trim($fullName);
$username = trim($username);
$password = trim($password);

if ($fullName === '' || $username === '' || $password === '') {
    header("Location: register.php?error=generic");
    exit;
}

try {
    // Use prepared statement (no need for manual escaping)
    $stmt = $conn->prepare(
        "INSERT INTO users (username, password, full_name, role)
         VALUES (?, ?, ?, 'member')"
    );
    $stmt->bind_param("sss", $username, $password, $fullName);
    $stmt->execute();

    // Success: auto-login new member
    $_SESSION['user_id']   = $stmt->insert_id;
    $_SESSION['full_name'] = $fullName;
    $_SESSION['role']      = 'member';

    header("Location: member_dashboard.php");
    exit;

} catch (mysqli_sql_exception $e) {
    // 1062 = duplicate entry for UNIQUE key (username)
    if ($e->getCode() == 1062) {
        header("Location: register.php?error=duplicate");
        exit;
    } else {
        // Any other DB error
        // You could log $e->getMessage() somewhere if you wanted
        header("Location: register.php?error=generic");
        exit;
    }
}
