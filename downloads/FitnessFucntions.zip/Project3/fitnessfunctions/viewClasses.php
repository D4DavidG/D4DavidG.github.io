<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'member') {
    header("Location: login.php");
    exit;
}

$memberId = (int)$_SESSION['user_id'];

$query = "
    SELECT c.*, i.name AS instructor_name,
           COUNT(e.id) AS enrolled_count,
           SUM(CASE WHEN e.member_id = $memberId THEN 1 ELSE 0 END) AS is_enrolled
    FROM classes c
    JOIN instructors i ON c.instructor_id = i.id
    LEFT JOIN enrollments e ON c.id = e.class_id
    GROUP BY c.id
    ORDER BY c.class_time
";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Classes - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <div class="card-header">
        <h1>Available Classes</h1>
        <p class="subtitle">Browse and enroll in upcoming sessions.</p>
    </div>

    <div class="section-row">
        <div class="section-tag">Schedule</div>
        <?php
        // simple counts from the same result set (if you want)
        $totalClasses = $result ? $result->num_rows : 0;
        ?>
        <div class="section-tag">Total: <?= $totalClasses ?></div>
    </div>


    <?php if ($result && $result->num_rows > 0): ?>
        <table border="0" cellpadding="8" cellspacing="0">
            <tr>
                <th>Name</th>
                <th>Instructor</th>
                <th>Time</th>
                <th>Capacity</th>
                <th>Enrolled</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['instructor_name']) ?></td>
                    <td><?= htmlspecialchars($row['class_time']) ?></td>
                    <td><?= htmlspecialchars($row['capacity']) ?></td>
                    <td><?= htmlspecialchars($row['enrolled_count']) ?></td>
                    <td>
                        <?php if ($row['is_enrolled'] > 0): ?>
                            Already enrolled
                        <?php elseif ($row['enrolled_count'] >= $row['capacity']): ?>
                            Full
                        <?php else: ?>
                            <a href="enroll.php?class_id=<?= $row['id'] ?>">Enroll</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No classes available.</p>
    <?php endif; ?>
</div>
</body>
</html>
