<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$query = "SELECT * FROM instructors ORDER BY name";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Instructors - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Manage Instructors</h1>

    <p><a href="addInstructor.php">➕ Add New Instructor</a></p>

    <?php if ($result && $result->num_rows > 0): ?>
        <table border="0" cellpadding="8" cellspacing="0">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Specialization</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['specialization']) ?></td>
                    <td>
                        <a href="editInstructorForm.php?id=<?= $row['id'] ?>">Edit</a> |
                        <a href="deleteInstructor.php?id=<?= $row['id'] ?>"
                           onclick="return confirm('Delete this instructor?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No instructors found yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
