<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'member') {
    header("Location: login.php");
    exit;
}

$memberId = (int)$_SESSION['user_id'];
$classId  = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

if ($classId > 0) {
    $delete = "DELETE FROM enrollments
               WHERE class_id = $classId
               AND   member_id = $memberId";
    $conn->query($delete);
}

header("Location: myClasses.php");
exit;
