<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="card nav-bar">
    <div class="brand">
        FITNESS<span>FUNCTIONS</span>
    </div>

    <div class="nav-links">
        <?php if (isset($_SESSION['full_name'])): ?>
            <?php
                $role      = $_SESSION['role'] ?? 'member';
                $roleClass = ($role === 'admin') ? 'role-admin' : 'role-member';
                $roleLabel = ($role === 'admin') ? 'Admin' : 'Member';
            ?>
            <span class="nav-user">
                <?php if ($role === 'admin'): ?>
                    Hello Site Admin
                <?php else: ?>
                    Hello <?= htmlspecialchars($_SESSION['full_name']) ?>
                <?php endif; ?>
                <span class="role-badge <?= $roleClass ?>">
                    <?= htmlspecialchars($roleLabel) ?>
                </span>
            </span>

            <?php if ($role === 'admin'): ?>
                <a href="admin_dashboard.php">Dashboard</a>
                <a href="manageInstructors.php">Instructors</a>
                <a href="manageClasses.php">Classes</a>
                <a href="viewEnrollments.php">Enrollments</a>
            <?php else: ?>
                <a href="member_dashboard.php">Dashboard</a>
                <a href="viewClasses.php">All Classes</a>
                <a href="myClasses.php">My Classes</a>
            <?php endif; ?>

            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>
</nav>

<script>
(function () {
    // Spotlight trail: target = actual mouse, current = spotlight position
    let targetX = 50;
    let targetY = 30;
    let currentX = 50;
    let currentY = 30;

    // Higher = faster catch-up, shorter trail; lower = slower, longer trail
    const ease = 0.05;

    document.addEventListener('pointermove', function (e) {
        targetX = (e.clientX / window.innerWidth) * 100;
        targetY = (e.clientY / window.innerHeight) * 100;
    });

    function animate() {
        currentX += (targetX - currentX) * ease;
        currentY += (targetY - currentY) * ease;

        document.documentElement.style
            .setProperty('--cursor-x', currentX + '%');
        document.documentElement.style
            .setProperty('--cursor-y', currentY + '%');

        requestAnimationFrame(animate);
    }

    animate();
})();
</script>
