<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$classQuery = "SELECT * FROM classes WHERE id = $id";
$classResult = $conn->query($classQuery);

if (!$classResult || $classResult->num_rows !== 1) {
    die("Class not found.");
}

$class = $classResult->fetch_assoc();

// Instructor list
$instQuery = "SELECT * FROM instructors ORDER BY name";
$instResult = $conn->query($instQuery);

// Convert 'YYYY-MM-DD HH:MM:SS' back to 'YYYY-MM-DDTHH:MM' for datetime-local
$classTimeRaw = $class['class_time'];
$dt = str_replace(' ', 'T', substr($classTimeRaw, 0, 16));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Class - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Edit Class</h1>

    <form action="handleEditClass.php" method="POST">
        <input type="hidden" name="id" value="<?= $class['id'] ?>">

        <label>
            Class Name<br>
            <input type="text" name="name"
                   value="<?= htmlspecialchars($class['name']) ?>" required>
        </label>
        <br>
        <label>
            Instructor<br>
            <select name="instructor_id" required>
                <?php while ($inst = $instResult->fetch_assoc()): ?>
                    <option value="<?= $inst['id'] ?>"
                        <?= ($inst['id'] == $class['instructor_id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($inst['name']) ?> (<?= htmlspecialchars($inst['specialization']) ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </label>
        <br>
        <label>
            Description<br>
            <input type="text" name="description"
                   value="<?= htmlspecialchars($class['description']) ?>">
        </label>
        <br>
        <label>
            Class Time<br>
            <input type="datetime-local" name="class_time"
                   value="<?= htmlspecialchars($dt) ?>" required>
        </label>
        <br>
        <label>
            Capacity<br>
            <input type="number" name="capacity"
                   value="<?= htmlspecialchars($class['capacity']) ?>" min="1" required>
        </label>
        <br>
        <input type="submit" value="Update Class">
    </form>

    <p><a href="manageClasses.php">← Back to Classes</a></p>
</div>
</body>
</html>
