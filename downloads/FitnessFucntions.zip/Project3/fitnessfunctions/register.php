<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<div class="card">
    <h1>Register New Member</h1>

    <?php if (isset($_GET['error']) && $_GET['error'] === 'duplicate'): ?>
        <p style="color:#ff8080;">
            That username is already taken. Please choose another.
        </p>
    <?php elseif (isset($_GET['error']) && $_GET['error'] === 'generic'): ?>
        <p style="color:#ff8080;">
            Something went wrong creating your account. Please try again.
        </p>
    <?php endif; ?>

    <form action="handleRegister.php" method="POST">
        <label>
            Full Name<br>
            <input type="text" name="full_name" required>
        </label>
        <br>
        <label>
            Username<br>
            <input type="text" name="username" required>
        </label>
        <br>
        <label>
            Password<br>
            <input type="password" name="password" required>
        </label>
        <br>
        <input type="submit" value="Create Account">
    </form>

    <p style="margin-top:0.75rem;">
        Already have an account? <a href="login.php">Login here</a>.
    </p>
</div>
</body>
</html>
<script>
(function () {
    // Spotlight trail: target = actual mouse, current = spotlight position
    let targetX = 50;
    let targetY = 30;
    let currentX = 50;
    let currentY = 30;

    // Higher = faster catch-up, shorter trail; lower = slower, longer trail
    const ease = 0.05;

    document.addEventListener('pointermove', function (e) {
        targetX = (e.clientX / window.innerWidth) * 100;
        targetY = (e.clientY / window.innerHeight) * 100;
    });

    function animate() {
        currentX += (targetX - currentX) * ease;
        currentY += (targetY - currentY) * ease;

        document.documentElement.style
            .setProperty('--cursor-x', currentX + '%');
        document.documentElement.style
            .setProperty('--cursor-y', currentY + '%');

        requestAnimationFrame(animate);
    }

    animate();
})();
</script>

