<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'member') {
    header("Location: login.php");
    exit;
}

$memberId = (int)$_SESSION['user_id'];
$classId  = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

if ($classId <= 0) {
    header("Location: viewClasses.php");
    exit;
}

// Check capacity and existing enrollment
$query = "
    SELECT c.capacity,
           COUNT(e.id) AS enrolled_count,
           SUM(CASE WHEN e.member_id = $memberId THEN 1 ELSE 0 END) AS is_enrolled
    FROM classes c
    LEFT JOIN enrollments e ON c.id = e.class_id
    WHERE c.id = $classId
    GROUP BY c.id
";

$result = $conn->query($query);
if (!$result || $result->num_rows !== 1) {
    die("Class not found.");
}

$row = $result->fetch_assoc();

if ($row['is_enrolled'] > 0) {
    // already enrolled
    header("Location: myClasses.php");
    exit;
}

if ($row['enrolled_count'] >= $row['capacity']) {
    // class full
    header("Location: viewClasses.php");
    exit;
}

// Insert enrollment
$insert = "INSERT INTO enrollments (class_id, member_id)
           VALUES ($classId, $memberId)";
$conn->query($insert);

header("Location: myClasses.php");
exit;
