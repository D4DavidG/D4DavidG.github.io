<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$query = "SELECT classes.*, instructors.name AS instructor_name
          FROM classes
          JOIN instructors ON classes.instructor_id = instructors.id
          ORDER BY class_time";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Classes - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Manage Classes</h1>

    <p><a href="addClass.php">➕ Add New Class</a></p>

    <?php if ($result && $result->num_rows > 0): ?>
        <table border="0" cellpadding="8" cellspacing="0">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Instructor</th>
                <th>Time</th>
                <th>Capacity</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['instructor_name']) ?></td>
                    <td><?= htmlspecialchars($row['class_time']) ?></td>
                    <td><?= htmlspecialchars($row['capacity']) ?></td>
                    <td>
                        <a href="editClassForm.php?id=<?= $row['id'] ?>">Edit</a> |
                        <a href="deleteClass.php?id=<?= $row['id'] ?>"
                           onclick="return confirm('Delete this class?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No classes found yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
