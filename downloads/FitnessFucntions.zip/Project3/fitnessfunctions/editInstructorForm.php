<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$query = "SELECT * FROM instructors WHERE id = $id";
$result = $conn->query($query);

if (!$result || $result->num_rows !== 1) {
    die("Instructor not found.");
}

$instructor = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Instructor - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Edit Instructor</h1>

    <form action="handleEditInstructor.php" method="POST">
        <input type="hidden" name="id" value="<?= $instructor['id'] ?>">

        <label>
            Name<br>
            <input type="text" name="name"
                   value="<?= htmlspecialchars($instructor['name']) ?>" required>
        </label>
        <br>
        <label>
            Specialization<br>
            <input type="text" name="specialization"
                   value="<?= htmlspecialchars($instructor['specialization']) ?>" required>
        </label>
        <br>
        <input type="submit" value="Update Instructor">
    </form>

    <p><a href="manageInstructors.php">← Back to Instructors</a></p>
</div>
</body>
</html>
