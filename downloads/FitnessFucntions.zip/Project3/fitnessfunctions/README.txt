Project 3 – FitnessFunctions
CIS 4004 – LAMP Application

========================================
1. Overview
========================================
FitnessFunctions is a simple gym class and membership manager built on a LAMP stack.

It supports two user roles:

  • Administrator – manages instructors and fitness classes, and views enrollments.
  • Member – views the class schedule, enrolls/drops classes, and views "My Classes".

The application demonstrates:

  • Login/registration
  • Role-based access control (admin vs member)
  • CRUD operations on multiple tables
  • One-to-many relationships between instructors, classes, and enrollments


========================================
2. Technology Stack
========================================
  • Apache HTTP Server
  • PHP
  • MySQL
  • HTML/CSS (dark theme with aquamarine accent)
  • Simple SVG favicon: fitnessfunctions-ff-icon.svg


========================================
3. Files and Folder Structure (Submission)
========================================
After unzipping `Project3.zip`, the structure is:

  Project3/
      apache/
          httpd.conf
      php/
          php.ini
      fitnessfunctions/
          (all PHP, CSS, and assets for the web application)
          README.txt
      fitnessfunctions.sql   (MySQL data dump, single self-contained file)

Inside the "fitnessfunctions" folder, key application files include:

  • index.php                – landing page that redirects to login
  • login.php                – login form
  • authenticate.php         – processes login and starts session
  • logout.php               – logs user out

  • register.php             – new member registration form
  • handleRegister.php       – handles registration and inserts new member

  • admin_dashboard.php      – admin home / dashboard
  • member_dashboard.php     – member home / dashboard

  • manageInstructors.php    – list/manage instructors
  • addInstructor.php        – form to add instructor
  • handleAddInstructor.php  – processes add instructor
  • editInstructorForm.php   – form to edit instructor
  • handleEditInstructor.php – processes edit instructor
  • deleteInstructor.php     – deletes an instructor

  • manageClasses.php        – list/manage fitness classes
  • addClass.php             – form to add class
  • handleAddClass.php       – processes add class
  • editClassForm.php        – form to edit class
  • handleEditClass.php      – processes edit class
  • deleteClass.php          – deletes a class

  • viewClasses.php          – member view of all classes (with enroll links)
  • enroll.php               – enrolls a member in a class
  • myClasses.php            – shows member’s enrolled classes (with drop links)
  • dropEnrollment.php       – drops a member from a class
  • viewEnrollments.php      – admin view of class enrollments

  • db.php                   – database connection settings
  • styles.css               – styling for all pages
  • menu.php                 – shared navigation and role-based menu
  • fitnessfunctions-ff-icon.svg – favicon


========================================
4. Database Setup (for the Grader)
========================================
The file `fitnessfunctions.sql` at the root of Project3 is a self-contained MySQL
dump of the `fitnessfunctions` database. It will create all tables and insert
sample data.

To load this using MySQL Workbench:

  1) Open MySQL Workbench and connect to your MySQL server.
  2) From the top menu, choose:
         Server -> Data Import...
  3) Under "Import Options", select:
         "Import from Self-Contained File"
     and browse to:
         Project3/fitnessfunctions.sql
  4) Under "Default Target Schema":
         • Either select an existing schema named "fitnessfunctions"
           OR create a new schema named "fitnessfunctions" and select it.
  5) Click "Start Import".

After import, you should see these tables in the `fitnessfunctions` schema:

  • users
  • instructors
  • classes
  • enrollments


========================================
5. Application Configuration
========================================

A. Apache
---------
1) Place the `fitnessfunctions` folder inside your Apache document root.
   Example (Windows):

     C:\Apache24\htdocs\fitnessfunctions

2) The included `apache/httpd.conf` file is the Apache configuration used for
   this project. Ensure that:

   • The DocumentRoot points to the parent folder that contains `fitnessfunctions`.
   • PHP is correctly loaded as a module or via FastCGI (depending on your setup).

3) Restart Apache after any configuration changes.

B. PHP
------
1) The included `php/php.ini` file is the PHP configuration used for this project.
   Notable requirements:

   • `mysqli` extension enabled (for MySQL access)
   • `error_reporting` / `display_errors` configured appropriately for development

2) Make sure your Apache/PHP installation uses this `php.ini` or an equivalent
   configuration.

C. Database Connection (db.php)
-------------------------------
In `fitnessfunctions/db.php`, the default connection settings are:

  $host   = "localhost";
  $dbuser = "root";      // MySQL username
  $dbpass = "root";      // MySQL password
  $dbname = "fitnessfunctions";

If your local MySQL credentials differ, update `$dbuser` and `$dbpass` accordingly.


========================================
6. Running the Application
========================================
1) Ensure MySQL is running and the `fitnessfunctions` database has been imported
   from `fitnessfunctions.sql` (see Section 4).

2) Ensure Apache is running and the `fitnessfunctions` folder is in the
   Apache document root.

3) In a web browser, navigate to:

    http://localhost/fitnessfunctions/login.php

4) You should see the login page (`login.php`).


========================================
7. Test Accounts
========================================
After importing the sample data, you can log in with:

Administrator:
  • Username: admin
  • Password: admin123

Example member:
  • Username: test
  • Password: test

You can also create new member accounts by clicking "Create an account" on the
login page. Usernames must be unique; duplicate usernames will show an error
message and redirect back to registration.


========================================
8. How to Test the Application (Step-by-Step)
========================================

A. Admin Flow
-------------
1) Go to:
     http://localhost/fitnessfunctions/login.php

2) Log in using the admin credentials:

     Username: admin
     Password: admin123

3) On `admin_dashboard.php` you can:
   • View quick stats (counts of members, instructors, classes).
   • Click "Manage Instructors" to:
       - Add new instructors
       - Edit existing instructors
       - Delete instructors
   • Click "Manage Classes" to:
       - View all classes (with instructor names and capacity)
       - Add new classes
       - Edit class details
       - Delete classes
   • Click "View Enrollments" to:
       - See each class, its instructor, and all enrolled members

4) Use the navigation bar to move between pages or log out.

B. Member Flow
--------------
1) From the login page, click "Create an account" (`register.php`) to register
   a new member account, OR log in using the test account (`test` / `test`).

2) After logging in as a member, you will see `member_dashboard.php`.

3) From the dashboard:
   • Click "View Classes" (`viewClasses.php`) to:
       - See all classes, instructors, times, capacities, and current enrollment
       - Click "Enroll" to enroll in a class (if capacity allows)
   • Click "My Classes" (`myClasses.php`) to:
       - View only the classes you’re enrolled in
       - Use the "Drop" link to drop a class (`dropEnrollment.php`)
   • Click "Logout" to end the session.


========================================
9. Database Relationships
========================================
  • One instructor -> many classes
      `instructors.id` -> `classes.instructor_id`

  • One class -> many enrollments
      `classes.id` -> `enrollments.class_id`

  • One member (user with `role = 'member'`) -> many enrollments
      `users.id` -> `enrollments.user_id`

These relationships are defined via foreign key constraints in
`fitnessfunctions.sql`.


========================================
10. Notes for the Grader
========================================
  • All required files for the assignment are included:
      - MySQL data dump: `fitnessfunctions.sql`
      - Source folder: `fitnessfunctions/`
      - Apache configuration: `apache/httpd.conf`
      - PHP configuration: `php/php.ini`
      - Additional resources: favicon SVG and CSS in `fitnessfunctions/`

  • To re-create the environment:
      - Import `fitnessfunctions.sql` into MySQL.
      - Use `httpd.conf` and `php.ini` as reference configurations.
      - Place `fitnessfunctions/` into the Apache document root.

End of README
