<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Get instructors for dropdown
$instQuery = "SELECT * FROM instructors ORDER BY name";
$instResult = $conn->query($instQuery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Class - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Add Class</h1>

    <form action="handleAddClass.php" method="POST">
        <label>
            Class Name<br>
            <input type="text" name="name" required>
        </label>
        <br>
        <label>
            Instructor<br>
            <select name="instructor_id" required>
                <option value="">-- Select Instructor --</option>
                <?php while ($inst = $instResult->fetch_assoc()): ?>
                    <option value="<?= $inst['id'] ?>">
                        <?= htmlspecialchars($inst['name']) ?> (<?= htmlspecialchars($inst['specialization']) ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </label>
        <br>
        <label>
            Description<br>
            <input type="text" name="description">
        </label>
        <br>
        <label>
            Class Time<br>
            <input type="datetime-local" name="class_time" required>
        </label>
        <br>
        <label>
            Capacity<br>
            <input type="number" name="capacity" min="1" required>
        </label>
        <br>
        <input type="submit" value="Save Class">
    </form>

    <p><a href="manageClasses.php">← Back to Classes</a></p>
</div>
</body>
</html>
