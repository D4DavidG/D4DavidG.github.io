<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FitnessFunctions Login</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<div class="card">
    <h1>Login</h1>

    <?php if (isset($_GET['error'])): ?>
        <p style="color: #ff8080;">Invalid username or password.</p>
    <?php endif; ?>

    <form action="authenticate.php" method="POST">
        <label>
            Username<br>
            <input type="text" name="username" required>
        </label>
        <br>
        <label>
            Password<br>
            <input type="password" name="password" required>
        </label>
        <br>
        <input type="submit" value="Login">
    </form>

    <p style="color: var(--text-muted); margin-top: 0.5rem;">
        Test accounts: <code>admin / admin123</code>, <code>jordan / pass123</code>.
    </p>

    <p style="margin-top:0.75rem;">
        New here? <a href="register.php">Create an account</a>.
    </p>

</div>
</body>
</html>
<script>
(function () {
    // Spotlight trail: target = actual mouse, current = spotlight position
    let targetX = 50;
    let targetY = 30;
    let currentX = 50;
    let currentY = 30;

    // Higher = faster catch-up, shorter trail; lower = slower, longer trail
    const ease = 0.05;

    document.addEventListener('pointermove', function (e) {
        targetX = (e.clientX / window.innerWidth) * 100;
        targetY = (e.clientY / window.innerHeight) * 100;
    });

    function animate() {
        currentX += (targetX - currentX) * ease;
        currentY += (targetY - currentY) * ease;

        document.documentElement.style
            .setProperty('--cursor-x', currentX + '%');
        document.documentElement.style
            .setProperty('--cursor-y', currentY + '%');

        requestAnimationFrame(animate);
    }

    animate();
})();
</script>
