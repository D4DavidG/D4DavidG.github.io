<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$query = "
    SELECT c.name AS class_name,
           c.class_time,
           i.name AS instructor_name,
           u.full_name AS member_name
    FROM enrollments e
    JOIN classes c ON e.class_id = c.id
    JOIN instructors i ON c.instructor_id = i.id
    JOIN users u ON e.member_id = u.id
    ORDER BY c.class_time, class_name, member_name
";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class Enrollments - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Class Enrollments</h1>

    <?php if ($result && $result->num_rows > 0): ?>
        <table border="0" cellpadding="8" cellspacing="0">
            <tr>
                <th>Class</th>
                <th>Time</th>
                <th>Instructor</th>
                <th>Member</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['class_name']) ?></td>
                    <td><?= htmlspecialchars($row['class_time']) ?></td>
                    <td><?= htmlspecialchars($row['instructor_name']) ?></td>
                    <td><?= htmlspecialchars($row['member_name']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No enrollments yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
