<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$name = $_POST['name'] ?? '';
$spec = $_POST['specialization'] ?? '';

$name = $conn->real_escape_string($name);
$spec = $conn->real_escape_string($spec);

$query = "INSERT INTO instructors (name, specialization)
          VALUES ('$name', '$spec')";

$conn->query($query);

header("Location: manageInstructors.php");
exit;
