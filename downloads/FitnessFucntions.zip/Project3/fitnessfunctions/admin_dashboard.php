<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <div class="card-header">
        <h1>Admin Dashboard</h1>
        <p class="subtitle">Welcome, Site Admin.</p>
    </div>

    <div class="card-grid">
        <a class="mini-card" href="manageInstructors.php">
            <div class="mini-card-title">Manage Instructors</div>
            <div class="mini-card-desc">Add, edit, or remove gym instructors.</div>
        </a>

        <a class="mini-card" href="manageClasses.php">
            <div class="mini-card-title">Manage Classes</div>
            <div class="mini-card-desc">Create and schedule new fitness classes.</div>
        </a>

        <a class="mini-card" href="viewEnrollments.php">
            <div class="mini-card-title">Class Enrollments</div>
            <div class="mini-card-desc">See who is enrolled in each class.</div>
        </a>
    </div>
</div>

</body>
</html>
