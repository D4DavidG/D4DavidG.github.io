<?php
session_start();
require_once "db.php";

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// basic cleanup
$username = $conn->real_escape_string(trim($username));
$password = $conn->real_escape_string(trim($password));

$sql = "SELECT * FROM users
        WHERE username = '$username'
          AND password = '$password'
        LIMIT 1";

$result = $conn->query($sql);

if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();

    $_SESSION['user_id']   = (int)$user['id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role']      = $user['role'];

    if ($user['role'] === 'admin') {
        header("Location: admin_dashboard.php");
    } else {
        // treat any non-admin as member
        header("Location: member_dashboard.php");
    }
    exit;
} else {
    // failed login
    header("Location: login.php?error=1");
    exit;
}
