<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['user_id'])) {
    // not logged in at all
    header("Location: login.php");
    exit;
}

if ($_SESSION['role'] !== 'member') {
    // logged in but wrong role
    echo "<div class='card'>";
    echo "<h1>Access denied</h1>";
    echo "<p>Your role is: " . htmlspecialchars($_SESSION['role']) . "</p>";
    echo "<p><a href='logout.php'>Back to login</a></p>";
    echo "</div>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Member Dashboard - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <div class="card-header">
        <h1>Member Dashboard</h1>
        <p class="subtitle">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?>.</p>
    </div>

    <div class="card-grid">
        <a class="mini-card" href="viewClasses.php">
            <div class="mini-card-title">View All Classes</div>
            <div class="mini-card-desc">
                See the full schedule and enroll in new workouts.
            </div>
        </a>

        <a class="mini-card" href="myClasses.php">
            <div class="mini-card-title">My Classes</div>
            <div class="mini-card-desc">
                Review your upcoming sessions and drop if needed.
            </div>
        </a>
    </div>
</div>

</body>
</html>
