<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id   = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$name = $_POST['name'] ?? '';
$spec = $_POST['specialization'] ?? '';

$name = $conn->real_escape_string($name);
$spec = $conn->real_escape_string($spec);

$query = "UPDATE instructors
          SET name = '$name',
              specialization = '$spec'
          WHERE id = $id";

$conn->query($query);

header("Location: manageInstructors.php");
exit;
