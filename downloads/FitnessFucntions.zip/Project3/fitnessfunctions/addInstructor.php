<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Instructor - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">
</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <h1>Add Instructor</h1>

    <form action="handleAddInstructor.php" method="POST">
        <label>
            Name<br>
            <input type="text" name="name" required>
        </label>
        <br>
        <label>
            Specialization<br>
            <input type="text" name="specialization" required>
        </label>
        <br>
        <input type="submit" value="Save Instructor">
    </form>

    <p><a href="manageInstructors.php">← Back to Instructors</a></p>
</div>
</body>
</html>
