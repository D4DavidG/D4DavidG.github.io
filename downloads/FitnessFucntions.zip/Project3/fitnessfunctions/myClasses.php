<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'member') {
    header("Location: login.php");
    exit;
}

$memberId = (int)$_SESSION['user_id'];

$query = "
    SELECT e.id AS enrollment_id,
           c.*, i.name AS instructor_name
    FROM enrollments e
    JOIN classes c ON e.class_id = c.id
    JOIN instructors i ON c.instructor_id = i.id
    WHERE e.member_id = $memberId
    ORDER BY c.class_time
";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Classes - FitnessFunctions</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/svg+xml" href="fitnessfunctions-ff-icon.svg">

</head>
<body>
<?php include "menu.php"; ?>

<div class="card">
    <div class="card-header">
        <h1>My Classes</h1>
        <p class="subtitle">All the classes you are currently enrolled in.</p>
    </div>

    <div class="section-row">
        <div class="section-tag">Enrolled</div>
    </div>



    <?php if ($result && $result->num_rows > 0): ?>
        <table border="0" cellpadding="8" cellspacing="0">
            <tr>
                <th>Name</th>
                <th>Instructor</th>
                <th>Time</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['instructor_name']) ?></td>
                    <td><?= htmlspecialchars($row['class_time']) ?></td>
                    <td>
                        <a href="dropEnrollment.php?class_id=<?= $row['id'] ?>"
                           onclick="return confirm('Drop this class?');">
                           Drop
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>You are not enrolled in any classes yet.</p>
    <?php endif; ?>
</div>
</body>
</html>
