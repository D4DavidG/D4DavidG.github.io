<?php
// db.php
$host = "localhost";
$dbuser = "root";     // change if your MySQL user is different
$dbpass = "root";     // change if your password is not root
$dbname = "fitnessfunctions";

$conn = new mysqli($host, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
