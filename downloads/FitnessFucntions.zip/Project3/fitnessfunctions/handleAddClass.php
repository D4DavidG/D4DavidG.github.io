<?php
session_start();
require_once "db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$name         = $_POST['name'] ?? '';
$instructorId = isset($_POST['instructor_id']) ? (int)$_POST['instructor_id'] : 0;
$description  = $_POST['description'] ?? '';
$classTimeRaw = $_POST['class_time'] ?? '';
$capacity     = isset($_POST['capacity']) ? (int)$_POST['capacity'] : 0;

// Convert from 'YYYY-MM-DDTHH:MM' to 'YYYY-MM-DD HH:MM:SS'
$classTime = str_replace('T', ' ', $classTimeRaw) . ':00';

$name        = $conn->real_escape_string($name);
$description = $conn->real_escape_string($description);
$classTime   = $conn->real_escape_string($classTime);

$query = "INSERT INTO classes (instructor_id, name, description, class_time, capacity)
          VALUES ($instructorId, '$name', '$description', '$classTime', $capacity)";

$conn->query($query);

header("Location: manageClasses.php");
exit;
